//
//  UITableViewCell+MLTagViewFrameRecord.m
//  MLLayoutDemo
//
//  Created by molon on 16/6/23.
//  Copyright © 2016年 molon. All rights reserved.
//

#import "UITableViewCell+MLTagViewFrameRecord.h"
#import <objc/runtime.h>
#import "MLTagViewFrameRecord.h"
#import "UITableView+MLTagViewFrameRecord.h"
#import "MLLayoutMacro.h"

MLLAYOUT_SYNTH_DUMMY_CLASS(UITableViewCell_MLTagViewFrameRecord)

@implementation UITableViewCell (MLTagViewFrameRecord)

+ (void)load {
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        void(^hook)(SEL sel) = ^(SEL sel) {
            SEL newSEL = NSSelectorFromString([NSString stringWithFormat:@"_mlLayout_hook_%@",NSStringFromSelector(sel)]);
            
            Method originalMethod = class_getInstanceMethod(self, sel);
            Method myMethod = class_getInstanceMethod(self,newSEL);
            method_exchangeImplementations(originalMethod, myMethod);
        };
        hook(@selector(layoutSubviews));
    });
}

- (void)_mlLayout_hook_layoutSubviews {
    [self _mlLayout_hook_layoutSubviews];
    
    UITableView *tableView = [self currentTableView];
    
    if (tableView) {
        NSIndexPath *indexPath = [tableView indexPathForCell:self];
        if (!indexPath) {
            return;
        }
        
        MLTagViewFrameRecord *frameRecord = [tableView cachedMLTagViewFrameRecordForRowAtIndexPath:indexPath];
        if (frameRecord) {
            [frameRecord layoutTagViewsWithRootView:self.contentView];
            return;
        }
    }
    
    if (self.contentView.frame.size.width<=0.0f) {
        return;
    }
    
    //layout
    [self layoutSubviewsIfNoFrameRecord];
}

- (void)layoutSubviewsIfNoFrameRecord {
    
}

- (UITableView*)currentTableView {
    UIView *view = self.superview;
    while (view&&![view isKindOfClass:[UITableView class]]) {
        view = view.superview;
    }
    return (UITableView*)view;
}

+ (CGFloat)heightUsingMLTagViewFrameRecordForRowAtIndexPath:(NSIndexPath*)indexPath tableView:(UITableView*)tableView beforeLayout:(nullable void (^)(UITableViewCell *protypeCell))beforeLayout {
    
    if (tableView.frame.size.width<=0.0f) {
        return 0.0f;
    }
    
    //find the cache
    MLTagViewFrameRecord *frameRecord = [tableView cachedMLTagViewFrameRecordForRowAtIndexPath:indexPath];
    if (frameRecord) {
        return frameRecord.frame.size.height;
    }
    
    static NSMutableDictionary *protypeCells = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        protypeCells = [NSMutableDictionary dictionary];
    });
    
    NSString *clsName = NSStringFromClass([self class]);
    UITableViewCell *protypeCell = protypeCells[clsName];
    if (!protypeCell) {
        protypeCell = [[self class]new];
        protypeCells[clsName] = protypeCell;
    }
    
    CGRect frame = protypeCell.frame;
    frame.size.width = tableView.frame.size.width;
    protypeCell.frame = frame;
    
    if (beforeLayout) {
        beforeLayout(protypeCell);
    }
    
    [protypeCell setNeedsLayout];
    [protypeCell layoutIfNeeded];
    
    //cache
    frameRecord = [protypeCell.contentView exportTagViewFrameRecord];
    [tableView cacheMLTagViewFrameRecord:frameRecord forRowAtIndexPath:indexPath];
    
    return frameRecord.frame.size.height;
}

@end
