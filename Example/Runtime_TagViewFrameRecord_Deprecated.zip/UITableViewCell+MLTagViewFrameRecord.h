//
//  UITableViewCell+MLTagViewFrameRecord.h
//  MLLayoutDemo
//
//  Created by molon on 16/6/23.
//  Copyright © 2016年 molon. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface UITableViewCell (MLTagViewFrameRecord)

/**
For override , like `layoutSubviews`, but it's only called when no frame record.
@warning Must ensure the final frame of `contentView` set. it's height is used for `heightWithTableView:indexPath:beforeLayout:` method.
@warning self.contentView.frame.size.height is meaningless at the begin of call.

Example:
- (void)layoutSubviewsIfNoFrameRecord {
    [_layout dirtyAllRelativeLayoutsAndLayoutViewsWithFrame:CGRectMake(0, 0, self.contentView.frame.size.width, kMLLayoutUndefined)]; //kMLLayoutUndefined is important if using MLLayout because of warning 2 upon.
}
*/
- (void)layoutSubviewsIfNoFrameRecord;

/**
 Get height of indexPath, if cached, return it directly.
 
 @param indexPath    indexPath
 @param tableView    tableView
 @param beforeLayout the prepare block before layout, do set model to cell or others.
 
 @return height of indexPath
 */
+ (CGFloat)heightUsingMLTagViewFrameRecordForRowAtIndexPath:(NSIndexPath*)indexPath tableView:(UITableView*)tableView beforeLayout:(nullable void (^)(UITableViewCell *protypeCell))beforeLayout;

@end

NS_ASSUME_NONNULL_END